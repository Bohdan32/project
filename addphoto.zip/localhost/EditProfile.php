<?php
session_start();

if (!$_SESSION['user']) {
  header('Location: Registration.php');
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
  <title>PicPad</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
</head>

<body>

  <nav class="" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="index.php" class="brand-logo logo">
        <img src="img/logo.png" alt=""></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="core/logoutZ.php" class="logout">Вихід</a></li>
        <li class="active"><a href="Profile.php">Профіль</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="core/logoutZ.php" class="logout">Вихід</a></li>
        <li class="active"><a href="Profile.php">Профіль</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>



  <div class="wrapper">
    <form enctype="multipart/form-data" action="core/editP.php" method="post">
      <div class="container">
        <div class="row" style="margin-top: 4%;">
          <div class="col s5 m4 l3">
            <img src="img/user.png" alt="" class="circle" style="height: 73%; width: 73%;">
          </div>
          <div class="col s7 m8 l9">
            <div class="input-field col s6">
              <input id="first_name" type="text" class="validate" name="username" value="<?= $_SESSION['user']['name'] ?>">
              <label for="first_name">Псевдонім</label>
            </div>
            <!--psevdonim-->
            <div class="input-field col s12">
              <textarea id="textarea1" name="bio" class="materialize-textarea"><?= $_SESSION['user']['bio'] ?></textarea>
              <label for="textarea1">Автобіографія</label>
            </div>

          </div>
          <div class="row">
            <div class="col s12 m12 l12" style="margin-top: 4%;">
              <button class="col s6 m4 l2 but" type="submit" style="padding: 10px 10px; margin-top:16px; margin-right: 2%;">Зберегти</button>


              <div class="col s5 m7 l9 file-field input-field">
                <div class="btn">
                  <span>Змінити аватарку</span>
                  <input name="profilephoto" type="file">
                </div>
              </div>



            </div>
          </div>


        </div>
        <div>
    </form>
  </div>


  <div class="row">
    <div class="col s2 m3 l4"></div>
    <h5 class="col s8 m6 l4">Роботи користувача</h5>
    <div class="col s2 m3 l4"></div>
  </div>

  <form enctype="multipart/form-data" action="core/editP.php" method="post">
    <div class="row">
      <div class="col s3 m3 l4"></div>
      <div class="col s6 m6 l4 file-field input-field">
        <div class="btn">
          <span>Додати ілюстрацію</span>
          <input type="file" multiple>
        </div>
      </div>
      <div class="col s3 m3 l4"></div>
    </div>
  </form>

  <div class="row">
    <div class="col s12 m12 l12">
      <img src="img/img (1).jpg" alt="" class="  rad" style="margin-top: 2%;">
     
    </div>
  </div>
  </div>

  </div>


  <footer class="page-footer ">
    <div class="container">
      <div class="row" style="margin-bottom: 0px;">
        <div class="col l6 s12">
          <h5 class="white-text"></h5>

        </div>

        <div class="col l3 s12">
          <h5 class="white-text"></h5>
          <ul>

          </ul>
        </div>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>

</html>