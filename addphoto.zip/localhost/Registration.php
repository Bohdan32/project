<?php
session_start();
if ($_SESSION['user']) {
  header('Location: Profile.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
  <title>PicPad</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
</head>

<body class="reg">

  <nav class="" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="index.php" class="brand-logo logo">
        <img src="img/logo.png" alt=""></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li class="active"><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li class="active"><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>


  <div class="wrapper">

    <div class="container">
      <div class="section row">
        <div class="col s0 m2 l3"></div>
        <div class="card cardrozmir col s12 m8 l6 z-depth-3">
          <div class="card-content">
            <span class="card-title center">Реєстрація</span>
            <!--/////////////////////////////////////////////////////////////////////////////////////// -->
            <div class="row">
              <form class="col s12 m12 l12" action="core/signupZ.php" method="post">
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">account_circle</i>
                    <input id="first_name" type="text" class="validate" name="username">
                    <label for="first_name" class="black-text">Псевдонім</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">email</i>
                    <input id="email" type="email" class="validate" name="email">
                    <label for="email" class="black-text">Email</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">vpn_key</i>
                    <input id="password" type="password" class="validate" name="password">
                    <label for="password" class="black-text">Пароль</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">vpn_key</i>
                    <input id="password" type="password" name="password_confirm" class="validate">
                    <label for="password" class="black-text">Підтвердити пароль</label>
                  </div>
                </div>
                <div class="center">
                  <h6>
                    <input type="checkbox" id="test5" />
                    <label for="test5">Я приймаю <a href="umovi.php" target="_blank">Умови використання</a> та <a href="pravula.php" target="_blank">Політику
                        конфіденційності</a> </label>
                  </h6>
                  <button id="register_button" type="submit" name="register" value="true">Зареєструватися</button>
                  <!--<a class="waves-effect waves-light btn" href="Profile.html">Зареєструватися</a> -->
                </div>
              </form>
            </div>
            <!--/////////////////////////////////////////////////////////////////////////////////////// -->

          </div>
        </div>
        <div class="col s0 m2 l3"></div>
      </div>
    </div>

  </div>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>

</html>