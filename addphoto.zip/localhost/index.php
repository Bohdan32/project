<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
  <title>PicPad</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
</head>

<body>

  <nav class="" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="index.php" class="brand-logo logo">
        <img src="img/logo.png" alt=""></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>



  <div class="wrapper">

    <div class="container">
      <div class="section">
      <form>
        <div class="input-field">
          <input id="search" type="search" required>
          <label class="label-icon" for="search"></label>
          <i class="material-icons">close</i>
        </div>
      </form>
        <img src="img/img (1).jpg" alt="" class="  rad" style="margin-top: 2%;"><!-- photo -->


      </div>
    </div>

  </div>


  <footer class="page-footer ">
    <div class="container">
      <div class="row" style="margin-bottom: 0px;">
        <div class="col l6 s12">
          <h5 class="white-text"></h5>

        </div>

        <div class="col l3 s12">
          <h5 class="white-text"></h5>
          <ul>

          </ul>
        </div>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>

</html>