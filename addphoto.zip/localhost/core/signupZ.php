<?php

    session_start();
    require_once 'connectZ.php';

    $name = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if ($password == $password_confirm) {

        $password = ($password);

        mysqli_query($connect, "INSERT INTO `users`(`name`, `password`, `email`) VALUES ('$name','$password','$email')");

        $_SESSION['message'] = 'Регистрация прошла успешно!';
        header('Location: ../profile.php');


    } else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location: ../register.php');
    }

?>
