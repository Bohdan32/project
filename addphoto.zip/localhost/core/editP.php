<?php

require_once '../core/connectZ.php';


session_start();

$path = 'img/' . time() . $_FILES['profilephoto']['name'];
    if (!move_uploaded_file($_FILES['profilephoto']['tmp_name'], '../' . $path)) {
       $_SESSION['message'] = 'error';
       header('Location: ../EditProfile.php');
    }else{
        echo("ok");
    }


$id = $_SESSION['user']['id'];
$name = $_POST['username'];
$bio = $_POST['bio'];
$profilephoto = $_POST['profilephoto'];

/*
 * Делаем запрос на изменение строки в таблице products
 */

mysqli_query($connect, "UPDATE `users` SET `name` = '$name', `bio` = '$bio', `profilephoto` = '$path' WHERE `users`.`id` = '$id'");

/*
 * Переадресация на главную страницу
 */

header('Location: /Profile.php');