<?php

    $connect = mysqli_connect('localhost', 'root', '', 'registration-bd');

    if (!$connect) {
        die('Error connect to DataBase');
    }