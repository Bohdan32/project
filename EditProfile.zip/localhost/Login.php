<?php
session_start();

if ($_SESSION['user']) {
    header('Location: Profile.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
  <title>PicPad</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
</head>

<body class="reg">

  <nav class="" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="index.php" class="brand-logo logo">
        <img src="img/logo.png" alt=""></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li><a href="Registration.php">Зареєструватися</a></li>
        <li class="active"><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="AboutUs.php">Про нас</a></li>
        <li><a href="Registration.php">Зареєструватися</a></li>
        <li class="active"><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>


  <div class="wrapper">

    <div class="container">
      <div class="section row">
        <div class="col s0 m2 l3"></div>
        <div class="card cardrozmir col s12 m8 l6 z-depth-3">
          <div class="card-content">
            <span class="card-title center">Вхід</span>
              <form action="core/signinZ.php" method="post"><!--/////////////////////////////////////////////////////////////////////////////////////// -->
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">email</i>
                    <input id="email" name="email" type="email" class="validate">
                    <label for="email" name="email" class="black-text">Email</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">vpn_key</i>
                    <input id="password" type="password" name="password" class="validate">
                    <label for="password" name="password" class="black-text">Пароль</label>
                  </div>
                    <?php
                    if ($_SESSION['message']) {
                      echo '<p class="msg"> ' . $_SESSION['message'] . ' </p>';
                    }
                    unset($_SESSION['message']);
                    ?>
                </div>
                <div class="center">
                  <button type="submit">Вхід</button>
                </div>
              </form>
            </div>
            <!--/////////////////////////////////////////////////////////////////////////////////////// -->

          </div>
        </div>
        <div class="col s0 m2 l3"></div>
      </div>
    </div>

  </div>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>

</html>