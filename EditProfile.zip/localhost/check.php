<?php
    $name = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
  
    $conn = new mysqli('localhost', 'root', '', 'registration-bd');
    if ($conn->connection_error) {
        die("Connection failed: ".$conn->connect_error);
    }else{
        $conn->query("INSERT INTO `users`(`name`, `password`, `email`) VALUES ('$name','$password','$email')");
        //$conn->execute();
        echo "Registr successfully..";
        $conn->close();
    }
?>