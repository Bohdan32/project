<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
  <title>PicPad</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
</head>

<body>

  <nav class="" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="index.php" class="brand-logo logo">
        <img src="img/logo.png" alt=""></a>
      <ul class="right hide-on-med-and-down">
        <li class="active"><a href="AboutUs.php">Про нас</a></li>

        <li><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li class="active"><a href="AboutUs.php">Про нас</a></li>

        <li><a href="Registration.php">Зареєструватися</a></li>
        <li><a href="Login.php">Вхід</a></li>
        <li><a href="Profile.php">Профіль</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>

  <div class="wrapper">

    <div class="container">
      <div class="section">

        <h3 class="center">
          <b>Про нас</b>
        </h3>

        <div class="row">
          <div class="col s6 m6 l6">
            <h4 class="center ab">Сайт для ілюстраторів-аматорів</h4>
          </div>
          <div class="col s6 m6 l6 center">
            <img class="imgabout" src="img/aboutus1.jpg">
          </div>
        </div>

        <div class="row">
          <div class="col s6 m6 l6 center">
            <img class="imgabout" src="img/aboutus2.jpg">
          </div>
          <div class="col s6 m6 l6">
            <h4 class="center ab">Ілюстрація для тебе</h4>
          </div>
        </div>
        <h3 class="center">
          <b>Команда</b>
        </h3>
        <div class="row">
          <!--////////////////////////////////////////////////////////////////-->
          <div class="col s12 m6 l3">
            <div class="card z-depth-5">
              <div class="card-image">
                <img src="img/bohdan.jpg">
                <span class="card-title">Дякун Богдан</span>
              </div>
              <div class="card-content">
                <ul>
                  <li>Teamlead</li>
                  <li>Frontend/Backend developer</li>
                </ul>
              </div>
            </div>
          </div>
          <!--////////////////////////////////////////////////////////////////-->
          <div class="col s12 m6 l3">
            <div class="card z-depth-5">
              <div class="card-image">
                <img src="img/yura.jpg">
                <span class="card-title">Ткачишин Юра</span>
              </div>
              <div class="card-content">

                <ul>
                  <li>DataBase</li>
                  <li>Frontend/Backend developer</li>
                </ul>

              </div>
            </div>
          </div>
          <!--////////////////////////////////////////////////////////////////-->
          <div class="col s12 m6 l3">
            <div class="card z-depth-5">
              <div class="card-image">
                <img src="img/sasha.jpg">
                <span class="card-title">Оленюк Олександр</span>
              </div>
              <div class="card-content">
                <ul>
                  <li>Quality Assurance Manual</li>
                  <li>Copywriter</li>
                  <li></li>
                </ul>
              </div>
            </div>
          </div>
          <!--////////////////////////////////////////////////////////////////-->
          <div class="col s12 m6 l3">
            <div class="card z-depth-5">
              <div class="card-image">
                <img src="img/olya.jpg">
                <span class="card-title">Чигирик Ольга</span>
              </div>
              <div class="card-content">
                <ul>
                  <li>UI/UX Designer</li>
                  <li>Copywriter</li>
                  <li></li>
                </ul>
              </div>
            </div>
          </div>
          <!--////////////////////////////////////////////////////////////////-->
        </div>
        <h5 class="center"><b> Проект створений студентами першого курсу групи ІТ-12 для предмету ПКР</b></h5>

      </div>
    </div>


    <footer class="page-footer ">
      <div class="container">
        <div class="row" style="margin-bottom: 0px;">
          <div class="col l6 s12">
            <h5 class="white-text"></h5>

          </div>

          <div class="col l3 s12">
            <h5 class="white-text"></h5>
            <ul>

            </ul>
          </div>
        </div>
      </div>
    </footer>

  </div>
  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>

</html>